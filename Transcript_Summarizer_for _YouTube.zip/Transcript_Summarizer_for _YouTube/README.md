
## Installation

1. Clone the repository in your local machine.
```
git clone https://github.com/reenajasmineedwin/Transcript_Summarizer_for_YouTube.git
```

2. To run the API, you need to set up a **Virtual Environment**. Go into *youtube-transcript-summarizer-api* folder, open command prompt and paste the following command.
```
python -m venv venv
```

3. Now that you got a Virtual Environment created, it's time to install all the **dependencies**. Use the following command.   
```
pip install -r requirements.txt
```
4. Now it's time to run the **API**.
```
python app.py
```
5. Now the API is set up to provide the response. Its time to start with **frontend**.
```
cd ..
cd youtube-transcript-summarizer-frontend
```
6. Install all the required **node modules**.
```
npm install
```
7. You are all set to run the frontend.
```
npm start
```

